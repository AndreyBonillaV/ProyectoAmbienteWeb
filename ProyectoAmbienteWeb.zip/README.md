# ProyectoAmbienteWeb
Proyecto Ambiente Web / Página de venta de artículos tecnologicos

Integrantes: 
- Víctor Andrei Bonilla Valerín
- Blondy Soto
- Carlos Morales

Herramientas de trabajo:
- MySql 
- PHP
- Git / GitHub
- Xampp
- JavaScript
